tsc -p tsconfig.json
cp views build/views -r